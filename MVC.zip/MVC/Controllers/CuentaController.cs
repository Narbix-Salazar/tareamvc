﻿using System.Linq;
using System.Web.Mvc;
using MVC.Models;

namespace MVC.Controllers
{
    public class CuentaController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string usuario, string contraseña)
        {
            var user = db.Usuarios.SingleOrDefault(u => u.Nombre == usuario && u.Contraseña == contraseña);
            if (user != null)
            {
                // Autenticación exitosa
                Session["UsuarioId"] = user.Id;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // Autenticación fallida
                ViewBag.Message = "Usuario o contraseña incorrecta";
                return View();
            }
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
    }
}